<?php
namespace Opencart\Admin\Model\Extension\Polkadot\Payment;

class Polkadot extends \Opencart\System\Engine\Model {
	public function install(): void {
	}
	public function uninstall(): void {
	}

/*
	public function getReports(int $download_id, int $start = 0, int $limit = 10): array {
	}
	public function getTotalReports(): int {
	}
*/
}
